let numero = parseFloat(prompt("digite o valor ao lado"))

function minhaFunçao(numero2){
  return (numero2*numero2)
}
let x = minhaFunçao(numero)
console.log(x)
