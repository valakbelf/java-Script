const nota1 = parseFloat(prompt("Nota 1: "));
const nota2 = parseFloat(prompt("Nota 2: "));
const nota3 = parseFloat(prompt("Nota 3: "));
const nota4 = parseFloat(prompt("Nota 4: "));
console.log("A média é:", (nota1 + nota2 + nota3 + nota4) / 4);
