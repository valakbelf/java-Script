const numero = parseInt(prompt("Digite um número: "));
console.log(numero % 2 === 0 ? "Par" : "Ímpar");
