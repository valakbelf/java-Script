function somarnumero(num1, num2, num3) {
    console.log("A soma é:", num1 + num2 + num3);
}

const num1 = parseFloat(prompt("Número 1: "));
const num2 = parseFloat(prompt("Número 2: "));
const num3 = parseFloat(prompt("Número 3: "));
somarnumero(num1, num2, num3);
