const base = parseFloat(prompt("Digite o valor da base: "));
const altura = parseFloat(prompt("Digite o valor da altura: "));
console.log("A área é:", (base * altura) / 2);
